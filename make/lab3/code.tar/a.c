//a.c
#include <stdio.h>

void a(){

	printf("function a\n");
}
