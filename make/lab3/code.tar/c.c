//c.c
#include <stdio.h>

void c(){
	printf("function c\n");

}
