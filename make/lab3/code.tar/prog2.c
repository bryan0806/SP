// prog2.c
#include <stdio.h>
#include "abc.h"
int main(){
	b();
	a();
	c();
	return 0; /*same as exit(0);*/

}
