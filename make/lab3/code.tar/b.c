//b.c
#include <stdio.h>

void b(){

	printf("function b\n");
}
