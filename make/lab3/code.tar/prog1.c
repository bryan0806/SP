// prog1.c
#include <stdio.h>
#include <stdlib.h>
#include "abc.h"

int main(){
	a();
	b();
	c();
	exit(0);

}
