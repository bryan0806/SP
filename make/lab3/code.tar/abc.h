// abc.h
void a();
void b();
void c();
